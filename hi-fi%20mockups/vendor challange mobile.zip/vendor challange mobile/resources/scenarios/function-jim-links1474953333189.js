(function(window, undefined) {

  var jimLinks = {
    "4cc1e0c8-40ca-457e-8db8-6e01c3f61fee" : {
    },
    "9e024fb3-2b52-496d-8897-813505edfcdb" : {
    },
    "2809b5a6-ccea-4a76-a036-9185ec4db49d" : {
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
    }    
  }

  window.jimLinks = jimLinks;
})(window);