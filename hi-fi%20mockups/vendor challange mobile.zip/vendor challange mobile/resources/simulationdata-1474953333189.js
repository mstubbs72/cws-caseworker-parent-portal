function initData() {
  jimData.variables["menu"] = "1";
  jimData.isInitialized = true;
}